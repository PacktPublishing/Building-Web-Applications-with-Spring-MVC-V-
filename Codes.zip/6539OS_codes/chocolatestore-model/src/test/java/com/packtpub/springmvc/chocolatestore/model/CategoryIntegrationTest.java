package com.packtpub.springmvc.chocolatestore.model;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Category.class)
public class CategoryIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
