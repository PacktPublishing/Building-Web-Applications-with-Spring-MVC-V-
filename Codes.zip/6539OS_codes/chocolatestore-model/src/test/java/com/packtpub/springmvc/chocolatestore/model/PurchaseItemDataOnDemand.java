package com.packtpub.springmvc.chocolatestore.model;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = PurchaseItem.class)
public class PurchaseItemDataOnDemand {
}
