package com.packtpub.springmvc.chocolatestore.model;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Customer.class)
public class CustomerDataOnDemand {
}
