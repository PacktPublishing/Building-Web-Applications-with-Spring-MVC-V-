package com.packtpub.springmvc.chocolatestore.model.service;
import org.springframework.roo.addon.layers.service.RooService;

@RooService(domainTypes = { com.packtpub.springmvc.chocolatestore.model.PurchaseItem.class })
public interface PurchaseItemService {
}
