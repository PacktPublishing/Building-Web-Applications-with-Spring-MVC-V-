package com.packtpub.springmvc.chocolatestore.model.service;

public class PurchaseServiceImpl implements PurchaseService {
}
