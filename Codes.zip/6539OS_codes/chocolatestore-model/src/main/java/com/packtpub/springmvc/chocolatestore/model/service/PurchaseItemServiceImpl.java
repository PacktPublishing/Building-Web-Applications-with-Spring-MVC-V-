package com.packtpub.springmvc.chocolatestore.model.service;

public class PurchaseItemServiceImpl implements PurchaseItemService {
}
