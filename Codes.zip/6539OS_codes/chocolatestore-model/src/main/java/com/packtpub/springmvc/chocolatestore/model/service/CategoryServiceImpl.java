package com.packtpub.springmvc.chocolatestore.model.service;

public class CategoryServiceImpl implements CategoryService {
}
