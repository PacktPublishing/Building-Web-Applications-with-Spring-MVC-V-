package com.packtpub.springmvc.chocolatestore.model.service;
import org.springframework.roo.addon.layers.service.RooService;

@RooService(domainTypes = { com.packtpub.springmvc.chocolatestore.model.Category.class })
public interface CategoryService {
}
